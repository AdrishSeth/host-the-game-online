var ground,monkey,score,banana,obstacles;

function preload(){
monkey_running =       loadAnimation("sprite_0.png","sprite_1.png","sprite_2.png","sprite_3.png","sprite_4.png","sprite_5.png","sprite_6.png","sprite_7.png","sprite_8.png");
bananaImage=loadImage("banana.png");
obstacleImage=loadImage("obstacle.png");
}

function setup(){
  createCanvas(600,600);
  ground=createSprite(300,400,1200,5);
  ground.velocityX=-100;
  ground.x=ground.width/2;
  
  monkey=createSprite(100,390,20,20);
  monkey.addAnimation("moving",monkey_running);
  monkey.scale=0.1;
  
  score=0;
}

function draw(){
  background(0);
  
  
text("Score: "+ score, 500,100);
  
  if(keyDown("space")){
  monkey.velocityY=-12;   
  }
  
  if(ground.x<0){
    ground.x=ground.width/2;
  } 
  
  monkey.velocityY=monkey.velocityY+0.8;
  monkey.collide(ground);
  
  spawnbananas();
  spawnobstacles();
  
  drawSprites();
}

function spawnbananas(){
  if(frameCount % 100 === 0)
  {
  banana=createSprite(400,250,10,10);   
  banana.x=Math.round(random(700,250));
  banana.addImage("banana",bananaImage);
  banana.scale=0.08;
  banana.velocityX=-2;   
  banana.lifetime=200;  
  }
} 

function spawnobstacles(){
  if(frameCount % 100 ===0)
    {
    obstacle=createSprite(600,385,10,10);
    obstacle.x=Math.round(random(700,385));  
    obstacle.addImage("obstacle",obstacleImage);
    obstacle.scale=0.08;  
    obstacle.velocityX=-1;  
    }
}